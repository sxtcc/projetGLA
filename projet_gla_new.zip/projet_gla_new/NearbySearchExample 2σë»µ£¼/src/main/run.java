package main;

import main.moudle.Entry;
import main.moudle.FunSearchResult;

import java.util.ArrayList;

/**
 * Created by shenshen on 17/1/10.
 */
public class run {
    public static void main(String[] args) throws Exception{
        
        
        NearbySearchExample nearbySearchExample = new NearbySearchExample();
        //        ArrayList<FunSearchResult> funSearchResults = nearbySearchExample.getNearbyFunSearchByInputOnly(null,null,null,"Bastille Square","potato");
        ArrayList<Entry> entrants = new ArrayList<Entry>();
        //Add participant name participant address participant preferences
        entrants.add(new Entry("a","Bastille Square","Chinesefood"));
        entrants.add(new Entry("b", "Place de la Bastille", "Chinesefood"));
        entrants.add(new Entry("c", "34bis Rue Amelot", "Fastfood"));
        entrants.add(new Entry("d", "Place Louis Armand Gare de Lyon Salle des fresques Music Railway SNC", "Fastfood"));
        
        ArrayList<FunSearchResult> funSearchResults = nearbySearchExample.getNearbyFunSearchByInput("2016-05-03 08:00:00","2016-05-03 22:00:00",entrants);
        
        //If you search the destination address, print it out
        if(funSearchResults!=null){
            String result =
            "Start Address:"+funSearchResults.get(0).getStartAddress()+"\n"+
            "Target bar:" + funSearchResults.get(0).getTitle() + "," + funSearchResults.get(0).getAddress() + "\n"+
            "Target Restaurant:" + funSearchResults.get(1).getTitle() + "," + funSearchResults.get(1).getAddress() + "\n"+
            "Target Club:" + funSearchResults.get(2).getTitle() + "," + funSearchResults.get(2).getAddress() + "\n"+
            "Time cost:" + (funSearchResults.get(0).getCostTime() + funSearchResults.get(1).getCostTime() + funSearchResults.get(2).getCostTime() + 210) + "minute" + "\n";
            System.out.println(result);
        }
        
    }
}
