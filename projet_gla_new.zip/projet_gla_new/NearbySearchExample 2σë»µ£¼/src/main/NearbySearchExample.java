package main;/*
              Exemple de requête de recherche de lieu
              * de type 'restaurant'
              * dans un rayon de 500 m
              * autour de la Place de la Bastille (coordonnées GPS décimales: 48.855218,2.368622)
              * contenant 'burger' dans le nom de l'enseigne
              */

/*
 Pour compiler et exécuter ce programme:
 > make
 > make run
 */

/**
 * Created by zhang haoyu on 17/2/21.
 */

import main.moudle.Entry;
import main.moudle.FunSearchResult;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class NearbySearchExample implements GetNearbyFunSearch{
    
    // METTEZ ICI VOTRE CLE D'API DE GOOGLE PLACES
    private static String GooglePlacesKey = "AIzaSyD57LwjxaaKMAMMsmVo_P2bzr4N8Wd-PrI";
    private static long costTime = 48*3600;
    //Want to go three places
    private String type1 = "bar";
    private String type2 = "restaurant";
    private String type3 = "nightclub";
    //The business hours are from 8 a.m. to about 10 in the evening
    private static int openTime = 8;
    private static int closeTime = 22;
    
    //Search scope
    private int average = 3000;//Search range 3 km
    
    public boolean judgeBusinessHours(Date startDate){
        
        boolean isInBusinessHours = false;
        
        Calendar cal=Calendar.getInstance();
        cal.setTime(startDate);
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        if(hour>=openTime&&hour<=closeTime){
            isInBusinessHours = true;
        }
        
        return isInBusinessHours;
    }
    
    @Override
    public ArrayList<FunSearchResult> getNearbyFunSearchByInput(String startDate,String endDate, ArrayList<Entry> entrants) {
        
        ArrayList<FunSearchResult> funSearchResults = new ArrayList<FunSearchResult>();
        boolean isOk = true;
        String message=null;
        String startAddress = null;
        
        //Determine the time interval between the two date units
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date startdate = null;
        Date enddate = null;
        try {
            startdate = formatter.parse(startDate);
            enddate = formatter.parse(endDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long diff = (enddate.getTime() - startdate.getTime())/(1000*60);
        
        if(diff<0){
            isOk = false;
            message = "Date entered is incorrect.";
        }
        
        FunSearchResult firstfunSearchResult = null,secondfirstfunSearchResult=null,thirdfunSearchResult=null;
        
        //starting point ->The nearest bar
        if(isOk) {
            //			String startAddress = entrants.get(0).getAddress();
            //			//Search for the nearest bar
            //			String[] out = getCoordinate(startAddress);
            //Search for the nearest bar
            String[] out = getCenterStartAddress(entrants);
            startAddress = getAddress(out);
            //			System.out.println(startAddress);
            ArrayList<FunSearchResult> firstfunSearchResults = getNearbySearch(out[0], out[1], average, type1, "",startAddress);
            //Find out the nearest
            if (firstfunSearchResults.size() > 0) {
                firstfunSearchResult = getNearestPlace(startAddress, firstfunSearchResults);
                funSearchResults.add(firstfunSearchResult);
                if(firstfunSearchResult.getCostTime()+30>diff){
                    isOk = false;
                    message = "Bar too far away, beyond the planning time";
                }
                if(!judgeBusinessHours(new Date(startdate.getTime()+(firstfunSearchResult.getCostTime()+30)*1000*60))){
                    isOk = false;
                    message = "Conflict with business hours";
                }
            } else {
                isOk = false;
                message = "No bar near the starting address";
            }
        }
        
        //target bar->restaurant
        if(isOk){
            ////Find the nearest restaurant away from target bar
            //Find the majority of the players like the restaurant
            //We take the two elements of the array offset each other, then there must be the most repeated elements
            int count = 0;
            int longest = 0;
            String favourate = null;
            for (int i = 0; i < entrants.size(); i++) {
                if (count == 0) {
                    favourate = entrants.get(i).getFavourateFood();
                    count++;
                } else {
                    if (favourate == entrants.get(i).getFavourateFood()) {
                        count++;
                    } else {
                        count--;
                    }
                }
            }
            String[] out = getCoordinate(firstfunSearchResult.getAddress());
            String address = firstfunSearchResult.getAddress();
            ArrayList<FunSearchResult> secondfunSearchResults = getNearbySearch(out[0], out[1], average, type2, favourate,startAddress);
            //Find out the nearest
            if(secondfunSearchResults.size()>0) {
                secondfirstfunSearchResult = getNearestPlace(address, secondfunSearchResults);
                funSearchResults.add(secondfirstfunSearchResult);
                if(firstfunSearchResult.getCostTime()+30+secondfirstfunSearchResult.getCostTime()+60>diff){
                    isOk = false;
                    message = "Restaurant too far away, beyond the planning time";
                }
                if(!judgeBusinessHours(new Date(startdate.getTime()+(firstfunSearchResult.getCostTime()+secondfirstfunSearchResult.getCostTime()+30+60)*1000*60))){
                    isOk = false;
                    message = "Travel time conflict with Restaurant";
                }
            }else{
                isOk = false;
                message = "No restaurant near the bar nearby";
            }
        }
        
        //target restaurant－>nightclub
        if(isOk){
            //Find the nearest nightclub away from target restaurant
            String[] out = getCoordinate(secondfirstfunSearchResult.getAddress());
            String address = secondfirstfunSearchResult.getAddress();
            ArrayList<FunSearchResult> thirdfunSearchResults = getNearbySearch(out[0], out[1], average, type3, "",startAddress);
            //Find out the nearest
            if(thirdfunSearchResults.size()>0) {
                thirdfunSearchResult = getNearestPlace(address, thirdfunSearchResults);
                funSearchResults.add(thirdfunSearchResult);
                if(firstfunSearchResult.getCostTime()+30+secondfirstfunSearchResult.getCostTime()+60+thirdfunSearchResult.getCostTime()+120>diff){
                    isOk = false;
                    message = "Nightclub too far away, beyond the planning time";
                }
                if(!judgeBusinessHours(new Date(startdate.getTime()+(firstfunSearchResult.getCostTime()+secondfirstfunSearchResult.getCostTime()+thirdfunSearchResult.getCostTime()+30+60+120)*1000*60))){
                    isOk = false;
                    message = "Travel time conflict with Restaurant";
                }
            }else{
                isOk = false;
                message = "No nightclub near the restaurant nearby";
            }
        }
        
        if(isOk) {
            return funSearchResults;
        }else{
            System.out.println("Match failed due to:"+message);
            String error  = "Match failed due to:"+message;
            ArrayList<FunSearchResult> funSearchResult = new ArrayList<FunSearchResult>();
            funSearchResult.add(new FunSearchResult(null,null,0,error,startAddress));
            return funSearchResult;
        }
    }
    
    //	@Override
    //	public ArrayList<FunSearchResult> getNearbyFunSearchByInputOnly(String startDate, String endDate, ArrayList<String> names, String address, String favourateFood) {
    //		ArrayList<FunSearchResult> funSearchResults = new ArrayList<FunSearchResult>();
    //
    //		//Find the nearest restaurant
    //		String[] out = getCoordinate(address);
    //		address = getAddress(out);
    //		ArrayList<FunSearchResult> firstfunSearchResults = getNearbySearch(out[0], out[1], average, type1, "");
    //		//Find out the nearest
    //		FunSearchResult firstfunSearchResult = getNearestPlace(address,firstfunSearchResults);
    //		funSearchResults.add(firstfunSearchResult);
    //
    //		//Find the nearest restaurant away from target bar
    //		out = getCoordinate(firstfunSearchResult.getAddress());
    //		address = firstfunSearchResult.getAddress();
    //		ArrayList<FunSearchResult> secondfunSearchResults = getNearbySearch(out[0], out[1], average, type2, favourateFood);
    //		//Find out the nearest
    //		FunSearchResult secondfirstfunSearchResult = getNearestPlace(address,secondfunSearchResults);
    //		funSearchResults.add(secondfirstfunSearchResult);
    //
    //
    //		//Find the nearest  nightclub away from target restaurant
    //		out = getCoordinate(secondfirstfunSearchResult.getAddress());
    //		address = secondfirstfunSearchResult.getAddress();
    //		ArrayList<FunSearchResult> thirdfunSearchResults = getNearbySearch(out[0], out[1], average, type3, "");
    //		//Find out the nearest
    //		FunSearchResult thirdfunSearchResult = getNearestPlace(address,thirdfunSearchResults);
    //		funSearchResults.add(thirdfunSearchResult);
    //
    //		return funSearchResults;
    //	}
    
    //Get latitude and longitude by address
    public static String[] getCoordinate(String addr) {
        String[] latLng = new String[2];
        
        try {
            addr = java.net.URLEncoder.encode(addr, "UTF-8");
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        };
        
        URL url = null;
        String html_output = null;
        try {
            url = new URL("https://maps.google.com/maps/api/geocode/json?address="+addr+"&sensor=false&key=");
            Scanner scan = new Scanner(url.openStream());
            html_output = new String();
            while (scan.hasNext())
                html_output += scan.nextLine();
            scan.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Construire l'objet JSON
        // Toute la documentation de la bibliothèque org.json est disponible sur https://stleary.github.io/JSON-java/index.html
        JSONObject j = new JSONObject(html_output);
        //		System.out.println (j.toString());
        
        JSONArray o2 = (JSONArray) j.get("results");
        JSONObject o3 =  (JSONObject) o2.get(0);
        JSONObject o4 = (JSONObject) o3.get("geometry");
        JSONObject o5 = (JSONObject)o4.get("location");
        latLng[0]=  o5.get("lat").toString();
        latLng[1]=  o5.get("lng").toString();
        
        return latLng;
    }
    
    //Get address information by latitude and longitude
    public static String getAddress(String[] latLng){
        
        String address = null;
        
        URL url = null;
        String html_output = null;
        try {
            url = new URL("https://maps.google.com/maps/api/geocode/json?latlng="+latLng[0]+","+latLng[1]+"&sensor=false&key=");
            Scanner scan = new Scanner(url.openStream());
            html_output = new String();
            while (scan.hasNext())
                html_output += scan.nextLine();
            scan.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        JSONObject j = new JSONObject(html_output);
        //		System.out.println (j.toString());
        JSONArray o1 = (JSONArray)j.get("results");
        
        JSONObject o2 = (JSONObject)o1.get(0);
        address = String.valueOf(o2.get("formatted_address"));
        
        return address;
    }
    
    
    
    //Get the information of all title stores in an area with a radius of m
    public static ArrayList<FunSearchResult>getNearbySearch(String lat, String lng, int m, String type, String title,String startAddress){
        // Lire une URL
        URL url = null;
        String html_output = null;
        ArrayList<FunSearchResult> funSearchResults = new ArrayList<FunSearchResult>();
        try {
            url = new URL("https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="+lat+","+lng+"&radius="+m+"&type="+type+"&name="+title+"&key=" + GooglePlacesKey);
            Scanner scan = new Scanner(url.openStream());
            html_output = new String();
            while (scan.hasNext())
                html_output += scan.nextLine();
            scan.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Construire l'objet JSON
        // Toute la documentation de la bibliothèque org.json est disponible sur https://stleary.github.io/JSON-java/index.html
        JSONObject j = new JSONObject(html_output);
        //		System.out.println(j.toString());
        JSONArray result = j.getJSONArray("results");
        
        // Afficher
        for (int i = 0 ; i < result.length() ; i++){
            JSONObject lieu = result.getJSONObject (i);
            //			System.out.println ("  -> " + lieu.getString ("name") + ", " + lieu.getString ("vicinity"));
            String name = lieu.getString("name");
            String address = lieu.getString("vicinity");
            funSearchResults.add(new FunSearchResult(name, address,0,null,startAddress));
        }
        return funSearchResults;
    }
    
    //Time to get location a to place b
    public long calculateTimeCost(String address_a,String address_b){
        long cost=0;
        
        try {
            address_a = java.net.URLEncoder.encode(address_a, "UTF-8");
            address_b = java.net.URLEncoder.encode(address_b, "UTF-8");
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        };
        
        URL url = null;
        String html_output = null;
        try {
            url = new URL("https://maps.googleapis.com/maps/api/distancematrix/json?"+"origins="+address_a+"&destinations="+address_b+"&key=" + GooglePlacesKey);
            Scanner scan = new Scanner(url.openStream());
            html_output = new String();
            while (scan.hasNext())
                html_output += scan.nextLine();
            scan.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Construire l'objet JSON
        // Toute la documentation de la bibliothèque org.json est disponible sur https://stleary.github.io/JSON-java/index.html
        JSONObject j = new JSONObject(html_output);
        //		System.out.println(j.toString());
        
        JSONArray o2 = (JSONArray) j.get("rows");
        JSONObject o3 =  (JSONObject) o2.get(0);
        JSONArray o4 = (JSONArray) o3.get("elements");
        JSONObject o5 =  (JSONObject) o4.get(0);
        JSONObject o6 =  (JSONObject) o5.get("duration");
        
        cost = (int) o6.get("value");
        //		}
        return cost;
    }
    
    //Search for the least time address
    public FunSearchResult getNearestPlace(String start,ArrayList<FunSearchResult> funSearchResults){
        FunSearchResult funSearchResult = new FunSearchResult();
        long lastcost = costTime;
        
        for(int i=0;i<funSearchResults.size();i++){
            long cost = calculateTimeCost(start, funSearchResults.get(i).getAddress());
            if(lastcost>cost){
                funSearchResult = funSearchResults.get(i);
                funSearchResults.get(i).setCostTime(cost);
                lastcost = cost;
            }
        }
        //		System.out.println(funSearchResult.getAddress()+funSearchResult.getTitle()+funSearchResult.getCostTime());
        return funSearchResult;
    }
    
    //找到所有参与者的最近的地址
    public String[] getCenterStartAddress(ArrayList<Entry> entrants){
        String[] latLng = new String[2];
        float lat = 0.0f;
        float lng = 0.0f;
        
        for(int i=0;i<entrants.size();i++){
            String[] out = getCoordinate(entrants.get(i).getAddress());
            if(null!=out[0]&&null!=out[1]) {
                lat = lat + Float.parseFloat(out[0]);
                lng = lng + Float.parseFloat(out[1]);
            }
        }
        latLng[0] = lat/entrants.size()+"";
        latLng[1] = lng/entrants.size()+"";
        return latLng;
    }
}
