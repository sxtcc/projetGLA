package main;

/**
 * Created by zhang haoyu on 17/2/21.
 */

import main.moudle.Entry;
import main.moudle.FunSearchResult;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class NearbySearch{
    public static void main(String args[])throws Exception{
        
        NewFrame frame1 = new NewFrame();
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//一定要设置关闭
        
        frame1.setVisible(true);
    }
}
class NewFrame extends JFrame{
    private JLabel label0;
    private JTextField text0;
    private JLabel label1;
    private JTextField text1;
    private JLabel label2;
    private JTextField text2;
    private JLabel label3;
    private JTextField text3;
    private JLabel label4;
    private JButton button1;
    private JButton button2;
    private JComboBox box;
    
    private JLabel label5;
    private JLabel label6;
    private JTextArea textArea;
    private JTextArea textArea2;
    NearbySearchExample nearbySearchExample= new NearbySearchExample();
    ArrayList<Entry> entrants = new ArrayList<Entry>();
    ArrayList<FunSearchResult> funSearchResults = new ArrayList<FunSearchResult>();
    String input ="";
    
    
    public NewFrame(){
        super();
        this.setSize(800, 400);
        this.getContentPane().setLayout(null);//设置布局控制器
        this.add(this.getLabel0(), null);//添加标签
        this.add(this.getTextField0(), null);//添加文本框
        this.add(this.getLabel(), null);//添加标签
        this.add(this.getTextField(), null);//添加文本框
        this.add(this.getLabel1(),null);//添加标签
        this.add(this.getTextField1(), null);//添加文本框
        this.add(this.getLabel2(),null);//添加标签
        this.add(this.getTextField2(), null);//添加文本框
        this.add(this.getLabel3(),null);//添加标签
        this.add(this.getBox(),null);//添加下拉列表框
        this.add(this.getButton(),null);//添加按钮
        this.add(this.getButton1(),null);//添加按钮
        this.add(this.getLabel5(),null);//添加标签
        this.add(this.getJTextArea(),null);//添加文本区
        this.add(this.getLabel6(),null);//添加标签
        this.add(this.getJTextArea2(),null);//添加文本区
        this.setTitle("NearbySearch!");//设置窗口标题
        
    }
    
    /**
     * 设置标签
     * @return 设置好的标签
     */
    private JLabel getLabel0(){
        if(label0==null){
            label0 = new JLabel();
            label0.setBounds(15,30,80,30);
            label0.setText("StartData");
            label0.setToolTipText("JLabel");
        }
        return label0;
    }
    /**
     * 设定文本域
     * @return
     */
    private JTextField getTextField0(){
        if(text0==null){
            text0 = new JTextField();
            text0.setBounds(96, 30, 160, 30);
        }
        return text0;
    }
    
    /**
     * 设置标签
     * @return 设置好的标签
     */
    private JLabel getLabel(){
        if(label1==null){
            label1 = new JLabel();
            label1.setBounds(15,80,80,30);
            label1.setText("EndDate");
            label1.setToolTipText("JLabel");
        }
        return label1;
    }
    /**
     * 设定文本域
     * @return
     */
    private JTextField getTextField(){
        if(text1==null){
            text1 = new JTextField();
            text1.setBounds(96, 80, 160, 30);
        }
        return text1;
    }
    
    /**
     * 设置标签
     * @return 设置好的标签
     */
    private JLabel getLabel1(){
        if(label2==null){
            label2 = new JLabel();
            label2.setBounds(15,130,80,30);
            label2.setText("Name");
            label2.setToolTipText("JLabel");
        }
        return label2;
    }
    /**
     * 设定文本域
     * @return
     */
    private JTextField getTextField1(){
        if(text2==null){
            text2 = new JTextField();
            text2.setBounds(96, 130, 160, 30);
        }
        return text2;
    }
    
    /**
     * 设置标签
     * @return 设置好的标签
     */
    private JLabel getLabel2(){
        if(label3==null){
            label3 = new JLabel();
            label3.setBounds(15,180,80,30);
            label3.setText("Address");
            label3.setToolTipText("JLabel");
        }
        return label3;
    }
    /**
     * 设定文本域
     * @return
     */
    private JTextField getTextField2(){
        if(text3==null){
            text3 = new JTextField();
            text3.setBounds(96, 180, 160, 30);
        }
        return text3;
    }
    
    /**
     * 设置标签
     * @return 设置好的标签
     */
    private JLabel getLabel3(){
        if(label4==null){
            label4 = new JLabel();
            label4.setBounds(15, 230, 80, 30);
            label4.setText("Restaurant");
            label4.setToolTipText("JLabel");
        }
        return label4;
    }
    /**
     * 设置下拉列表框
     * @return
     */
    private JComboBox getBox(){
        if(box==null){
            box = new JComboBox();
            box.setBounds(96, 230, 160, 30);
            box.addItem("Chinesefood");
            box.addItem("Koreanfood");
            box.addItem("Fastfood");
            box.addActionListener(new comboxListener());//为下拉列表框添加监听器类
            
        }
        return box;
    }
    private class comboxListener implements ActionListener{
        public void actionPerformed(ActionEvent e){
            Object o = e.getSource();
            System.out.println(o.toString());
        }
    }
    
    /**
     * 设置按钮
     * @return 设置好的按钮
     */
    private JButton getButton(){
        if(button1==null){
            button1 = new JButton();
            button1.setBounds(60, 280, 60, 40);
            button1.setText("Add");
            button1.setToolTipText("Add");
            button1.addActionListener(new AddButton());//添加监听器类，其主要的响应都由监听器类的方法实现
            
        }
        return button1;
    }
    /**
     * 监听器类实现ActionListener接口，主要实现actionPerformed方法
     * @author HZ20232
     *
     */
    private class AddButton implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if(!text2.getText().isEmpty()&& !text3.getText().isEmpty()){
                input = input+text2.getText()+","+text3.getText()+","+box.getSelectedItem()+"\n";
                textArea.setText(input);
                entrants.add(new Entry(text2.getText(), text3.getText(), (String) box.getSelectedItem()));
            }else{
                input = "";
                JOptionPane.showMessageDialog(null, "输入信息有误", "标题",JOptionPane.WARNING_MESSAGE);
            }
            text2.setText("");
            text3.setText("");
        }
    }
    
    
    /**
     * 设置按钮
     * @return 设置好的按钮
     */
    private JButton getButton1(){
        if(button2==null){
            button2 = new JButton();
            button2.setBounds(180,280,60,40);
            button2.setText("Run");
            button2.setToolTipText("Run");
            button2.addActionListener(new RunButton());//添加监听器类，其主要的响应都由监听器类的方法实现
            
        }
        return button2;
    }
    /**
     * 监听器类实现ActionListener接口，主要实现actionPerformed方法
     * @author HZ20232
     *
     */
    private class RunButton implements ActionListener{
        public void actionPerformed(ActionEvent e){
            input ="";
            if(entrants.size()>0) {
                funSearchResults = nearbySearchExample.getNearbyFunSearchByInput(text0.getText(), text1.getText(), entrants);
                if(funSearchResults!=null){
                    if(funSearchResults.get(0).getAddress()!=null) {
                        String result =
                        "Start Address:"+funSearchResults.get(0).getStartAddress()+"\n"+
                        "Target bar:" + funSearchResults.get(0).getTitle() + "," + funSearchResults.get(0).getAddress() + "\n"+
                        "Target Restaurant:" + funSearchResults.get(1).getTitle() + "," + funSearchResults.get(1).getAddress() + "\n"+
                        "Target Club:" + funSearchResults.get(2).getTitle() + "," + funSearchResults.get(2).getAddress() + "\n"+
                        "Time cost:" + (funSearchResults.get(0).getCostTime() + funSearchResults.get(1).getCostTime() + funSearchResults.get(2).getCostTime() + 210) + "minute" + "\n";
                        textArea2.setText(result);
                    }else{
                        textArea2.setText(funSearchResults.get(0).getMessage());
                    }
                }
                entrants.clear();
            }else{
                JOptionPane.showMessageDialog(null, "输入信息有误", "标题", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    
    /**
     * 设置标签
     * @return 设置好的标签
     */
    private JLabel getLabel5(){
        if(label5==null){
            label5 = new JLabel();
            label5.setBounds(300,20,80,20);
            label5.setText("Input");
            label5.setToolTipText("JLabel");
        }
        return label5;
    }
    /**
     * 设置文本显示区域
     * @return 设置好的按钮
     */
    private JTextArea getJTextArea(){
        if(textArea==null){
            textArea = new JTextArea(10, 15);
            textArea.setBounds(300,40,450,130);
            textArea.setTabSize(4);
            textArea.setEditable(false);
            textArea.setLineWrap(true);// 激活自动换行功能
            textArea.setWrapStyleWord(true);// 激活断行不断字功能
            textArea.setBackground(Color.gray);
        }
        return textArea;
    }
    
    /**
     * 设置标签
     * @return 设置好的标签
     */
    private JLabel getLabel6(){
        if(label6==null){
            label6 = new JLabel();
            label6.setBounds(300, 170, 80, 20);
            label6.setText("Result");
            label6.setToolTipText("JLabel");
        }
        return label6;
    }
    /**
     * 设置文本显示区域
     * @return 设置好的按钮
     */
    private JTextArea getJTextArea2(){
        if(textArea2==null){
            textArea2 = new JTextArea(10, 15);
            textArea2.setBounds(300, 190, 450, 130);
            textArea2.setTabSize(4);
            textArea2.setEditable(false);
            textArea2.setLineWrap(true);// 激活自动换行功能
            textArea2.setWrapStyleWord(true);// 激活断行不断字功能
            textArea2.setBackground(Color.gray);
        }
        return textArea2;
    }
    
}