package main;

import main.moudle.Entry;
import main.moudle.FunSearchResult;

import java.util.ArrayList;

/**
 * Created by shenshen on 17/1/10.
 */
public interface GetNearbyFunSearch {
    //Address \ preferences are not unique
    ArrayList<FunSearchResult> getNearbyFunSearchByInput(String startDate,String endDate,ArrayList<Entry> entrants);
    
    //Address \ preferences unique
    //     ArrayList<FunSearchResult> getNearbyFunSearchByInputOnly(String startDate,String endDate,ArrayList<String> names,String address,String favourateFood);
}
