package main.moudle;

/**
 * Created by shenshen on 17/1/10.
 */
public class FunSearchResult {
    String title;
    String address;
    long costTime;
    String message;
    String startAddress;
    
    public FunSearchResult(){
        
    }
    
    public FunSearchResult(String title, String address, long costTime, String message, String startAddress) {
        this.title = title;
        this.address = address;
        this.costTime = costTime;
        this.message = message;
        this.startAddress = startAddress;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public long getCostTime() {
        return costTime;
    }
    
    public void setCostTime(long costTime) {
        this.costTime = costTime;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getStartAddress() {
        return startAddress;
    }
    
    public void setStartAddress(String startAddress) {
        this.startAddress = startAddress;
    }
}
