package main.moudle;

/**
 * Created by shenshen on 17/1/10.
 */
public class Entry {
    String name;
    String address;
    String favourateFood;
    
    public Entry(String name, String address, String favourateFood) {
        this.name = name;
        this.address = address;
        this.favourateFood = favourateFood;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getFavourateFood() {
        return favourateFood;
    }
    
    public void setFavourateFood(String favourateFood) {
        this.favourateFood = favourateFood;
    }
}
